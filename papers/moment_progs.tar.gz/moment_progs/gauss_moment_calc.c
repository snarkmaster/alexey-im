#include <stdio.h>
#include <stdlib.h>

#ifndef MAXK
#define MAXK 30
#endif

int map[MAXK][MAXK];

unsigned long long rec(const int K, int rem, int prev, int nOdd, int max, int dis) 
{
	if (!rem) {
		if (!map[0][prev])
			dis++;
		if (map[0][prev] % 2 && nOdd == 1 && max == dis) {
			int i, j, k;
			unsigned long long total = 1;
			map[0][prev]++;
			for (i = 0; i < K; ++i)
				for (j = 0; j <= i; ++j) {
					for (k = 1; k < map[j][i]; k += 2)
						total *= k;
				}
			map[0][prev]--;
			return total;
		}
		return 0;
	} else if (rem + 1 < nOdd || dis > max) 
		return 0;
	else {
		int i, a, b, disn;
		unsigned long long res = 0;
		for (i = 0; i <= max + 1; ++i) {
			if (i == prev)
				continue;
			else if (i < prev) {
				a = i;
				b = prev;
			} else {
				a = prev;
				b = i;
			}
			disn = dis + (map[a][b] == 0);
			map[a][b]++;
			if (map[a][b] % 2) 
				res += rec(K, rem - 1, i, nOdd + 1, max > i ? max : i, disn);
			else
				res += rec(K, rem - 1, i, nOdd - 1, max > i ? max : i, disn);
			map[a][b]--;
		}
		return res;
	}
}

int main(int argc, char **argv)
{
	int i, j, K, max;
	if (argc < 2 || (max = atoi(argv[1])) > MAXK)
		max = MAXK/2;
	for (K = 1; K < max; ++K) {
		for (i = 0; i < K; ++i)
			for (j = 0; j < K; ++j)
				map[i][j] = 0;
		printf("%lld\n", rec(K, K - 1, 0, 0, 0, 0));
	}
	return 0;
}
