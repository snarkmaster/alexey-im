#include <stdio.h>
#include <stdlib.h>

#ifndef K
#define K 4
#endif

int map[K][K];
#ifdef COUNTFREQ
unsigned long long mapTotal[K + 1];
#endif
#ifdef PRINTALL
int cur[K];
#endif 

int rec(int rem, int prev, int nOdd, int max, int dis) 
{
	if (!rem) {
		if (map[0][prev] % 2 && nOdd == 1 && max == dis) {
#if defined(PRINTALL) || defined(COUNTFREQ)
			int i, j;
#endif
#ifdef PRINTALL
			printf("%d :", max);
			for (i = 0; i < K; ++i)
				printf(" %d", cur[i]);
			printf(" 0 \n");
#endif
#ifdef COUNTFREQ
			map[0][prev]++;
			for (j = 0; j < K/2 + 1; ++j)
				for (i = 0; i < j; ++i)
					mapTotal[map[i][j]]++;
			map[0][prev]--;
#endif
			return 1;
		}
		return 0;
	} else if (rem + 1 < nOdd || dis > max) 
		return 0;
	else {
		int i, a, b, disn;
		int res = 0;
		for (i = 0; i <= max + 1; ++i) {
			if (i == prev)
				continue;
			else if (i < prev) {
				a = i;
				b = prev;
			} else {
				a = prev;
				b = i;
			}
			disn = dis + (map[a][b] == 0);
			map[a][b]++;
#ifdef PRINTALL
			cur[K - rem] = i;
#endif
			if (map[a][b] % 2) 
				res += rec(rem - 1, i, nOdd + 1, max > i ? max : i, disn);
			else
				res += rec(rem - 1, i, nOdd - 1, max > i ? max : i, disn);
			map[a][b]--;
		}
		return res;
	}
}

int main()
{
	int i, j;
#ifdef COUNTFREQ
	for (i = 0; i < K + 1; ++i)
		mapTotal[i] = 0;
#endif
	for (i = 0; i < K; ++i)
		for (j = 0; j < K; ++j)
			map[i][j] = 0;
	printf("%d\n", rec(K - 1, 0, 0, 0, 0));
#ifdef COUNTFREQ
	for (i = 0; i < K + 1; ++i)
		printf("%llu ", mapTotal[i]);
	printf("\n");
#endif
	return 0;
}
