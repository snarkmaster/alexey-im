#include <string.h>
#include <stdio.h>
#include "list.h"

#define MAXN			32
#define MAXH			(MAXN/2)

/* Our representation of a rooted tree is as a parenthetical 
	expression: ((())()()), which we write as the bit string
	1110010100. Hence the hard limit of 32 vertices. Not that
	one would want to enumerate more anyway. */
typedef unsigned long long Tree;
listDefine(Tree) TreeList;

TreeList l[MAXH]; 
int si[MAXH][MAXH+1];

#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) (((a) > (b)) ? (a) : (b))
#define bit(t, j) (((unsigned long)(t >> j)) & 1)

void print_tree(Tree t, int size)
{
	int j, seenone = 0;
	for (j = size*2 - 1; j >= 0; --j)
		if (bit(t, j)) {
			putchar('(');
			seenone = 1;
		} else
			putchar(seenone ? ')' : ' ');
	putchar('\n');
}

void rootedsearch(int n, int cur_h, int max_h, 
						int max_i, Tree t) 
{
	if (n == 0) {
		/* << 1 to close the last paren */
		print_tree(t = t << 1, MAXN);
		listAdd(l[cur_h], t); 
	} else {
		int i, h, maxi, maxh = min(max_h, n - 1);
		for (h = 0; h <= maxh; ++h) {
			int size = h + 1, new_h = max(cur_h, h + 1);
			if (h < max_h) 
				maxi = si[h][n];
			else
				/* If we are at max height, we mustn't exceed 
					the previous component */
				maxi = min(si[h][n], max_i);
			for (i = 0; i < maxi; ++i) {
				/*We see the beginning of the next size block*/
				if (i == si[h][size])
					++size;
				rootedsearch(n - size, new_h, h, i + 1, 
										 t << (2*size) | l[h]->data[i]);
			}
		}
	}
}

int main(int argc, char **argv)
{
	int i, j, max_size, max_height;

	if (argc < 2)
		return 1;
	max_size = atoi(argv[1]);
	max_height = max_size/2;

	for (i = 0; i < MAXH; ++i) {
		listNew(l[i], 1024);
		si[i][0] = 0;
	}

	/* Build rooted trees required to construct free trees on 
		max_size vertices;  i denotes number of edges */
	for (i = 0; i < max_size - 2; ++i) {
		int maxh = min(max_height - 1, max_size - i - 3);
		/* 1 means the opening paren for the root vertex */
		rootedsearch(i, 0, maxh, l[maxh]->size, 1);
		printf("size %d:\n", i + 1);
		for (j = 0; j < max_height; ++j) {
			si[j][i + 2] = (si[j][i + 1] = l[j]->size);
			printf("\t%d height %d\n", si[j][i + 1] - si[j][i], j);
		}
	}
	
	return 0;
}
