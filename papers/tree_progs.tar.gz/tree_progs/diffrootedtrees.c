#include <string.h>
#include <stdio.h>
#include "list.h"
#include "assert.h"

#define MAXN	32

typedef unsigned long long int Tree;
listDefine(Tree) TreeList;

#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) ((a) > (b) ? (a) : (b))

#define bit(t, j) (((unsigned long)(t >> j)) % 2)

void print_tree(Tree t, int size)
{
	int j;
	for (j = size*2 - 1; j >= 0; --j)
		if (bit(t, j))
			putchar('(');
		else
			putchar(')');
	printf("\n");
}

int check_tree(Tree t)
{
	int j, c = 0;
	for (j = MAXN*2 - 1; j >= 0 && !bit(t, j); --j);
	for (; j >= 0; --j) {
		c += 2*bit(t, j) - 1;
		if (c < 0)
			return 0;
	}
	return (c == 0);
}

void search(TreeList trees, int *sizeindex, Tree t, int min_index, int at_size, int n)
{
	int i;
	if (n == 0) {
		assert(check_tree(t << 1));
		listAdd(trees, t << 1);
	} else {
		int size = at_size;
		for (i = min_index; i < sizeindex[n/2]; ++i) {
			if (i == sizeindex[size])
				++size;
			search(trees, sizeindex, t << (2*size) | trees->data[i], i, size, n - size);
		}
		for (i = max(min_index, sizeindex[n-1]); i < sizeindex[n]; ++i)
			search(trees, sizeindex, t << (2*n) | trees->data[i], i, n, 0);
	}
}

int main(int argc, char **argv)
{
	TreeList trees;
	int sizeindex[MAXN + 1];
	int i, maxSize;

	if (argc < 2)
		return 1;
	else
		maxSize = atoi(argv[1]);

	listNewDefault(trees);
	sizeindex[0] = 0;
	#ifndef NDEBUG
		for (i = 1; i <= MAXN; ++i) /* We shouldn't touch these */
			sizeindex[i] = -10000000; 
	#endif
	
	for (i = 0; i < maxSize; ++i) {
		search(trees, sizeindex, 1, 0, 1, i);
		sizeindex[i + 1] = trees->size;
		printf("%d size %d\n", sizeindex[i + 1] - sizeindex[i], i + 1);
	}
	
	printf("%d total\n", trees->size);

	maxSize = 1;	
	for (i = 0; i < trees->size; ++i) {
		if (i == sizeindex[maxSize])
			++maxSize;
		if (i > 0 && trees->data[i-1] >= trees->data[i]) {
			print_tree(trees->data[i-1], maxSize);
			print_tree(trees->data[i], maxSize);
			printf("\n");
		}	
	}
	
	return 0;
}

