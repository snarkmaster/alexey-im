#include <string.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include "list.h"
#include "my_lapack.h"

#define MAXN			32
#define MAXW			(2*MAXN+1)
#define MAXD			(MAXN/2)
#define MKL_EPSILON 	0.00000001
#define EPSILON 		0.0000000001

typedef unsigned long long BitTree;
typedef struct {
	BitTree t;
	double s; /*automorphism group size*/
} Tree;
listDefine(Tree) TreeList;

typedef struct Depth {
	TreeList list;
	int sizeindex[MAXN+1]; /* Trees with size vertices are at indices < sizeindex[size] */
} Depth;

double factorial[MAXN+1];
int print_canonical = 0, print_matrices = 0, print_eigenvalues = 0;
int print_free_trees = 0, print_rooted_trees = 0, print_histogram = 0;
int compute_matrices = 0, compute_eigenvalues = 0;

#define MAX_BINS	2011

#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) (((a) > (b)) ? (a) : (b))
#define bit(t, j) (((unsigned long)(t >> j)) & 1)

void print_tree(Tree t, int size)
{
	int j, seenone = 0;
	for (j = size*2 - 1; j >= 0; --j)
		if (bit(t.t, j)) {
			putchar('(');
			seenone = 1;
		} else
			putchar(seenone ? ')' : ' ');
	printf(" %1.14f\n", t.s);
}

int check_tree(Tree t)
{
	int j, c = 0;
	for (j = MAXN*2 - 1; j >= 0 && !bit(t.t, j); --j);
	for (; j >= 0; --j) {
		c += 2*bit(t.t, j) - 1;
		if (c < 0)
			return 0;
	}
	return c == 0;
}

void rootedsearch(Depth *depth, Tree t, int cur_depth, int max_depth, 
						int max_index, int n, int run_length) 
{
	if (n == 0) {
		t.t = t.t << 1;
		t.s *= factorial[run_length];
		assert(check_tree(t) != 0);
		listAdd(depth[cur_depth].list, t);
	} else {
		int d, i, maxd = min(max_depth, n - 1);
		for (d = 0; d <= maxd; ++d) {
			int size = d + 1, maxi;
			int new_depth = max(cur_depth, d + 1);
			if (d < max_depth)
				maxi = depth[d].sizeindex[n];
			else
				maxi = min(depth[d].sizeindex[n], max_index);
			assert(maxi >= 0 && maxi <= depth[d].list->size);	
			for (i = 0; i < maxi; ++i) {
				Tree nt;
				if (i == depth[d].sizeindex[size])
					++size;
				nt.t = t.t << (2*size) | depth[d].list->data[i].t;
				nt.s = t.s * depth[d].list->data[i].s;
				if (d == max_depth && i == max_index - 1)
					rootedsearch(depth, nt, new_depth, d, i + 1, n - size, run_length + 1);
				else {
					nt.s *= factorial[run_length];
					rootedsearch(depth, nt, new_depth, d, i + 1, n - size, 1);
				}
			}
		}
	}
}

void print_matrix(double *mtrx, int n)
{
   int i, j, k;
	putchar('[');
   for (j = 0; j < n; ++j) {
      for (k = 0; k < n; ++k) {
			if (k > j)	i = j*n + k;
			else			i = k*n + j;
			if (j != 0 || k != 0) putchar(' ');
         printf("%1.0f", mtrx[i]);
      }
      if (j == n - 1) putchar (']');
		putchar('\n');
   }
}

int cur_size, num_bins;
double least_eig;
unsigned free_count = 0;
double labeled_count;
double cur_base_contrib;
double bins[MAX_BINS+1], minv, maxv;

void add_to_hist(double value, double contrib)
{
	if (value < minv)
		bins[0] += contrib;
	else if (value >= maxv - EPSILON)
		bins[num_bins - 1] += contrib;
	else 
		bins[(int)(((value - minv)*num_bins) / (maxv - minv))] += contrib;
}

void process_matrix(double *m, int n, double a) 
{
	double ae, e[MAXN], work[MAXW];
	int iwork[1], lwork = 2*n + 1, one = 1, info;
	int i;
	DSYEVD("N","L", &n, m, &n, e, work, &lwork, iwork, &one, &info);
	if (n % 2) {
		assert(fabs(e[n/2]) < MKL_EPSILON);
		add_to_hist(0, cur_base_contrib/a);
	}		
	for (i = (n+1)/2; i < n; ++i) {
		add_to_hist(e[i], cur_base_contrib/a);
		add_to_hist(-e[i], cur_base_contrib/a);
		if (print_eigenvalues)
			printf("%1.9f ", e[i]);
		ae = fabs(e[i]);
		if (ae > EPSILON && ae < least_eig)
			least_eig = ae;
		/* all trees have a symmetric spectrum */
		assert(fabs(e[i] + e[n-i-1]) < MKL_EPSILON);
	}
	if (print_eigenvalues)
		putchar('\n');
}

typedef struct {
	BitTree t;
	int s; 
} SizedTree;

int compare_canonical(const void *aa, const void *bb)
{
	SizedTree a = *((SizedTree *)aa), b = *((SizedTree *)bb);
	BitTree c, d;
	if (a.s < b.s) {
		c = b.t;
		d = (a.t << (2*(b.s - a.s)));
	} else {
		c = (b.t << (2*(a.s - b.s)));
		d = a.t;
	}
	if (c < d) 
		return -1;
	else if (c == d)
		return 0;
	else
		return 1;
}

BitTree canonicalize(BitTree t, int size, int flip)
{
	int i = 0, j = 1, prev_j, d1 = 1, d2 = 1;
	SizedTree c[MAXN];
	while (j < 2*size - 1) {
		int at = 0, depth = 1;
		prev_j = j;
		do {
			at += 1 - 2*bit(t, j);
			if (at > depth)
				depth = at;
			++j;
		} while (at != 0);
		if (depth > d1) {
			d2 = d1;
			d1 = depth;
		} else if (depth > d2) 
			d2 = depth;
		assert((j - prev_j) % 2 == 0);
		c[i].s = (j - prev_j) / 2;
		c[i].t = canonicalize((t >> prev_j) & (((BitTree)1 << (j - prev_j)) - 1), c[i].s, 0);
		++i;
	}
	qsort(c, i, sizeof(*c), compare_canonical);
	/*refuse to flip if two deepest components have same depth*/
	if (!flip || d1 == d2) {
		t = 1;
		for (j = 0; j < i; ++j) 
			t = t << (2*c[j].s) | c[j].t;
	} else {
		t = 3;
		for (j = 1; j < i; ++j) 
			t = t << (2*c[j].s) | c[j].t;
		t = ((t << 1) << 2*(c[0].s - 1)) | ((c[0].t >> 1) & (((BitTree)1 << 2*(c[0].s - 1)) - 1));
	}
	return t << 1;
}

void tree_matrix_and_ev(Tree t)
{
	double m[MAXN*MAXN];
	int i, stack[MAXN], top = 0, vert = 0;
	/* Compute the adjacency matrix of our tree */
	memset(m, 0, sizeof(*m)*cur_size*cur_size);
	for (i = 2*cur_size - 1; i >= 1; --i) {
		if (bit(t.t, i)) { 
			if (top > 0)
				m[cur_size*stack[top - 1] + vert] = 1;
			stack[top++] = vert++;
		} else
			--top;
		assert(top > 0);
	}
	if (print_matrices)
		print_matrix(m, cur_size);
	if (compute_eigenvalues)
		process_matrix(m, cur_size, t.s);
}

void process_tree(Tree t) 
{
	labeled_count += factorial[cur_size]/t.s;
	if (print_free_trees) {
		if (print_canonical) {
			BitTree t1 = canonicalize(t.t, cur_size, 0), t2 = canonicalize(t.t, cur_size, 1);
			t.t = max(t1, t2);
			print_tree(t, cur_size);
		} else
			print_tree(t, cur_size);
		assert(check_tree(t) != 0);
	}
	if (compute_matrices)
		tree_matrix_and_ev(t);
	++free_count;
}

void search(Depth *depth, Tree t, int max_depth, int max_index, int n, int pass, 
				int fc_index, BitTree *fc_tree, int *fc_depth, int run_length)
{
	if (n == 0) {
		t.t = t.t << 1;
		t.s *= factorial[run_length];
		process_tree(t);
	} else {
		static BitTree first_component;
		static int fc_size;
		int d, i, start = 0, maxd = min(max_depth, n - 1);
		if (pass == 1) {
			/* In order to disambiguate bicentral trees, we do the following.
				Delete the center edge, and compare the two components. We will
				only construct trees, where the component containing the root is 
				lexicographically smaller.
			
				In the case d2 = d1 - 1 (bicentral), the remaining vertices	
				(n of them) + 1 mustn't exceed in number the size of the first 
				component we'd already added. In other words, 
			*/
			if (n + 1 > fc_size)
				start = max_depth;
			else 
				start = max(0, max_depth - 1); /* second component can't have small depth */
				
			/* (bicentral case) If the two components (upon deleting the center 
				edge) are the same size, we want the first one to be 
				lexicographically >=.
				To achieve this, we deconstruct the first component by 
				deleting the root, and recording the remaining components
				in fc_tree and fc_depth. Then, as we recurse further,
				we make sure not to exceed these. 
				
				Warning: this only applies in the bicentral case. If d1 == d2,
				it should be business as usual.
			*/
			if (n + 1 == fc_size) {
				int i = 0, pos = 1, prev_pos;
				/* We read the bit-string in reverse to get a reversed list 
					of components in fc_*. This makes fc_index == -1
					a natural sentinel.
				*/
				while (pos < 2*fc_size - 1) {
					int c = 0, depth = 1;
					prev_pos = pos;
					do {
						c += 1 - 2*bit(first_component, pos);
						if (c > depth)
							depth = c;
						++pos;
					} while (c != 0);
					fc_depth[i] = depth - 1;
					fc_tree[i] = (first_component >> prev_pos) &
						(((BitTree)1 << (pos - prev_pos)) - 1);
					++i;
				}
				fc_index = i - 1;
				/* This would mean we can't have a bicentral tree */
				if (fc_depth[fc_index] < maxd - 1)
					start = max_depth;
			} else 
				fc_index = -1; /* This signals "nothing to check" */
		} else if (fc_index >= 0)
			/* (bicentral case) we don't want to test pieces with depths that are 
				larger than the corresponding piece in the first component. */
			maxd = min(maxd, fc_depth[fc_index]);
						
		for (d = start; d <= maxd; ++d) {	
			/* Now we want trees of depth d, not exceeding (max_depth, max_index) in 
				this order:
					if depth(a) > depth(b), => a > b
					otherwise, index(a in depth[d]) > index(a in depth[d]), => a > b
				and also not exceeding the available size. so size <= n
				special case (pass == 0):
					the second component is going to require at least d-1 + 1 vertices, 
					and so we can't take up more than n - d vertices with this one.
			*/
			int size = d + 1, maxi;
			if (pass == 0) 
				maxi = depth[d].sizeindex[n - d]; 
			else {
				if (d < max_depth)
					maxi = depth[d].sizeindex[n];
				else {
					if (pass == 1) /* non-bicentral tree */
						fc_index = -1;
					maxi = min(depth[d].sizeindex[n], max_index);
				}
			}
			assert(maxi >= 0 && maxi <= depth[d].list->size);	
			for (i = 0; i < maxi; ++i) {
				Tree nt;
				int new_rl;
				if (i == depth[d].sizeindex[size])
					++size;
				if (pass == 0) {
					first_component = depth[d].list->data[i].t;
					fc_size = size;
				}
				nt.t = t.t << (2*size) | depth[d].list->data[i].t;
				nt.s = t.s * depth[d].list->data[i].s;
				if (d == max_depth && i == max_index - 1)
					new_rl = run_length + 1;
				else {
					new_rl = 1;
					nt.s *= factorial[run_length];
				}
				/*	(bicentral case) if we hit the same tree as in first_component at
					this position, we try using it, but quit to disallow exceeding it
					lexicographically.
				*/
				if (fc_index >= 0 && depth[d].list->data[i].t == fc_tree[fc_index]) {
					if (fc_index == 0) /*trees hanging off both centers isomorphic*/
						nt.s *= 2;
					search(depth, nt, d, i + 1, 
							n - size, pass + 1, fc_index - 1, fc_tree, fc_depth, new_rl);
					break;
				}
				/* (bicentral case) since we're at something lex. smaller than 
					first_component already, we don't need to continue checking,
					so we pass -1 for fc_index */
				search(depth, nt, 
						d, i + 1, n - size, pass + 1, -1, fc_tree, fc_depth, new_rl);
			}
		}
	}
}

int main(int argc, char **argv)
{
	int i, j, max_size = 1, max_depth, total = 0;
	double p = 1.0;
	Depth depth[MAXD];
	Tree t;

	if (argc < 2) {
		printf("Usage: %s [-c] [-m] [-e] [-f] [-r] [-l] [-p p] [-h bins min max] max_size\n"
				 "  -c  print canonical form (as in Li-Ruskey)\n"
				 "  -m  print adjacency matrices\n"
				 "  -e  print eigenvalues (they're symmetric, so only non-negative)\n"
				 "  -f  print free trees\n"
				 "  -r  print auxiliary rooted trees\n"
				 "  -E  print least positive eigenvalue over trees of every size\n"
				 "  -p  set p for estimating the discrete spectrum of G(n, p/n)\n"
				 "  -h  print a histogram with given # of bins, minimum and maximum\n"
				 , argv[0]);
		return 1;
	}

	for (i = 1; i < argc; ++i) {
		if (argv[i][0] == '-')
			switch(argv[i][1]) {
				case 'c':
					print_canonical = !print_canonical; 
				break;
				case 'm':
					print_matrices = !print_matrices; 
				break;
				case 'e':
					print_eigenvalues = !print_eigenvalues; 
				break;
				case 'f':
					print_free_trees = !print_free_trees; 
				break;
				case 'r':
					print_rooted_trees = !print_rooted_trees; 
				break;
				case 'E':
					compute_eigenvalues = !compute_eigenvalues;
				break;
				case 'p':
					if (argc - i > 1) 
						p = atof(argv[++i]);
				break;
				case 'h':
					print_histogram = !print_histogram;
					if (argc - i > 3) {
						num_bins = atoi(argv[++i]);
						if (num_bins > MAX_BINS) {
							fprintf(stderr, "Too many bins.\n");
							return 0;
						}
						minv = atof(argv[++i]);
						maxv = atof(argv[++i]);
					}					
			}
		else
			max_size = atoi(argv[i]);
	}
	compute_eigenvalues = compute_eigenvalues || print_eigenvalues || print_histogram;
	compute_matrices = compute_eigenvalues || print_matrices;
	print_free_trees = print_free_trees || print_canonical;
	
	#define flag(c, v) ((v) ? (c) : ' ') 
	printf("Flags: %c%c%c%c%c%c%c; p=%1.6f, h=%d/[%1.6f,%1.6f]\n", flag('c', print_canonical), 
		flag('m', print_matrices), flag('e', print_eigenvalues), flag('f', print_free_trees), 
		flag('r', print_rooted_trees), flag('E', compute_eigenvalues), 
		flag('h', print_histogram), p, num_bins, minv, maxv);
		
	if (max_size > MAXN || max_size < 1) {
		fprintf(stderr, "Bad maximum size.");
		return 2;
	}
		
	max_depth = max_size/2;

	for (i = 0; i < MAXD; ++i) {
		listNew(depth[i].list, 1024);
		depth[i].sizeindex[0] = 0;
		#ifndef NDEBUG
			for (j = 1; j <= MAXN; ++j) 
				depth[i].sizeindex[j] = -10000000; 
		#endif
	}
	for (i = 0; i < num_bins; ++i)
		bins[i] = 0;

	factorial[0] = 1;
	for (i = 1; i <= MAXN; ++i)
		factorial[i] = factorial[i-1]*i;
	
	t.t = 1;
	t.s = 1;
	/* Build rooted trees -- not quite order n space used; i denotes number of edges */
	for (i = 0; i < max_size - 2; ++i) {
		int maxd = min(max_depth - 1, max_size - i - 3);
		rootedsearch(depth, t, 0, maxd, depth[maxd].list->size, i, 0);
		printf("size %d:\n", i + 1);
		for (j = 0; j < max_depth; ++j) {
			depth[j].sizeindex[i + 2] = (depth[j].sizeindex[i + 1] = depth[j].list->size);
			printf("\t%d depth %d\n", depth[j].sizeindex[i + 1] - depth[j].sizeindex[i], j);
		}
	}
	printf("all sizes:\n");
	for (j = 0; j < max_depth; ++j) {
		printf("\t%d depth %d\n", depth[j].list->size, j);
		total += depth[j].list->size;
	}
	printf("%d total\n", total);

	if (print_rooted_trees) {
		for (i = 0; i < max_depth; ++i) {
			int size = i + 1;
			printf("-- depth %d --\n", i);	
			for (j = 0; j < depth[i].list->size; ++j) {
				if (j == depth[i].sizeindex[size])
					++size;
				print_tree(depth[i].list->data[j], size);
			}
		}
	}

	printf("Here go the free trees:\n");
	for (cur_size = 1; cur_size <= max_size; ++cur_size) {
		/* d means we're attaching at least d + 1 vertices
			we also need to attach at least d-1 + 1 vertices as the second largest
			so, given d, we need to attach at least 2*d + 1 vertices
			We have cur_size-1 vertices to attach. Thus 2*d + 1 <= cur_size-1.
			In other words, d <= cur_size/2 - 1.
			We pass in a bogus maxi, since it's not used on the first pass.
		*/
		int prev_count = free_count;
		int check_depth[MAXN];
		BitTree check_tree[MAXN];
		least_eig = 9999;
		labeled_count = 0;
		/*Let f=((E T_k)/n),; then, f denotes the contribution of the trees of size 
			k=cur_size to the discrete spectrum. There are k^k-2 such labeled trees, 
			and an unlabeled tree with automorphism group size A corresponds to k!/A 
			different labeled trees. Only A varies among trees, so we store in 
			cur_base_contrib this quantity: (f*k!)/(k^(k-2)), awaiting only to 
			be divided by A. */
		cur_base_contrib = pow(p, cur_size - 1)*exp(-cur_size*p);
		if (cur_size < 3) {
			Tree t;
			if (cur_size == 1) {t.t = 2; t.s = 1;}
			else 					 {t.t = 12; t.s = 2;}
			process_tree(t);
		} else
			search(depth, t, cur_size/2 - 1, 0, cur_size - 1, 0, -1, check_tree,
			check_depth, 0);
		printf("%d size %d;", free_count - prev_count, cur_size);
		if (compute_eigenvalues) printf(" least eig %1.9f;", least_eig); 
		printf(" labeled count %1.2f\n", labeled_count);
		if (print_histogram) {
			printf("d_%d_%d=[", (int)((p + 0.00001) * 100), cur_size);
			for (i = 0; i < num_bins; ++i)
				printf("%1.15f ", bins[i]);
			printf("];\n");
		}
		fflush(stdout);
	}
	
	return 0;
}
