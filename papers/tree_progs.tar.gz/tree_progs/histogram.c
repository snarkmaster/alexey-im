#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define SIZE 3000000

int dblcomp(const void *a, const void *b)
{
	double c = *((const double *)a), d = *((const double*)b);
	return (c - d > 0) - (c - d < 0);
}

#define CRAPMAX 500
#define EPSILON 0.0000000001
#define MARGIN 0.0000001
#define MIN (0 + MARGIN)
#define MAX (1 - MARGIN)
#define MAX_BIN_COUNT 2011

int main(int argc, char **argv)
{
	int bin_count = MAX_BIN_COUNT;
	double *val, lambda;
	double minv, maxv, binc_shift;
	double binc[MAX_BIN_COUNT];
	double slambda = -1.0, sminv=-4.0, smaxv=4.0;
	int i, num;
	int hist[MAX_BIN_COUNT];
	char junk[CRAPMAX];
	if (argc >= 2)
		bin_count = atoi(argv[1]);
	if (argc >= 5) {
		slambda = atof(argv[2]);
		sminv = atof(argv[3]);
		smaxv = atof(argv[4]);
	}
	if (bin_count <= 0 || bin_count > MAX_BIN_COUNT)
		bin_count = MAX_BIN_COUNT;
	val = malloc(sizeof(*val) * SIZE);
	fgets(junk, CRAPMAX, stdin);
	while (sscanf(junk, "--- doing lambda %lf", &lambda) == 1) {
		num = 0;
		while (fgets(junk, 500, stdin) != NULL &&
				sscanf(junk, "%lf, ", val + num) == 1 && num < SIZE) ++num;
		if (num == SIZE) {
			fprintf(stderr, "Too much stuff!");
			return 1;
		}
		
		if (fabs(slambda - lambda) < EPSILON) {
			minv = sminv;
			maxv = smaxv;
		} else {
			qsort(val, num, sizeof(*val), dblcomp);
			minv = val[(int)(MIN * num)];
			maxv = val[(int)(MAX * num)];
		}
		
/*		printf("The list for lambda %f has %d numbers from %f to %f.\n", lambda, 
			(int)((MAX - MIN) * num), minv, maxv);*/
			
		for (i = 0; i < bin_count; ++i)
			hist[i] = 0;

		for (i = 0; i <= num; ++i) {
			if (val[i] < minv)
				++hist[0];
			else if (val[i] >= maxv - EPSILON)
				++hist[bin_count - 1];
			else 
				++hist[(int)(((val[i] - minv)*bin_count) / (maxv - minv))];
		}
		
		binc_shift = (maxv - minv)*(1.0/(bin_count-2));
		for (i = 0; i < bin_count; ++i)
			binc[i] = binc_shift*((double)i - 0.5) + minv;

		fprintf(stderr, "ftrees params for p=%0.6f: %d %1.12f %1.12f\n", 
					lambda, bin_count, minv, maxv);
		printf("h_%d = [", (int)((lambda + 0.00001) * 100));
		for (i = 0; i < bin_count; ++i) 
			printf("%f %d\n", binc[i], hist[i]);
		printf("];");
		
/*		for (i = 0; i < bin_count; ++i) 
			printf("b: %f < %f <= %f : %d\n", binl[i], binc[i], binu[i], hist[i]);*/
	}
	return 0;
}
