#ifndef LIST_H
#define LIST_H

/***
	list.h: A generic, templated list library for C by Alexey Spiridonov.
	May be distributed under the terms of the GNU GPL version 2 (or greater, at
	your discretion).
	No warranties of any kind.
	
	Customized version: No NULL checking, no growSize.
***/
	
/*Uncomment to compile in C++; ANSI C doesn't allow these features, but C++ requires them.*/
/*#define CPP_ADJUST*/
#ifdef CPP_ADJUST
	#define CPP_ADJUST1	(void *)
#else
	#define CPP_ADJUST1
#endif

#define DEFAULT_SIZE						131072
#define DEFAULT_INCREMENT				262144

#include <stdlib.h>

/*Define a list of a given type*/
#define listDefine(type)		typedef struct { \
	int nAllocated; \
	int size; \
	type *data; \
} * 

/*Allocate a list with some initial size and subsequent growth increment*/
#define listNew(list, nItems) { \
	(CPP_ADJUST1(list)) = malloc(sizeof(*(list))); \
	(list)->size = 0; \
	(list)->nAllocated = (nItems); \
	(CPP_ADJUST1(list)->data) = malloc((nItems) * sizeof(*(list)->data)); \
}

#define listNewDefault(list) { \
	listNew((list), DEFAULT_SIZE) \
}

/*Grow a list to a specified size*/
#define listGrow(list, toSize) { \
	if ((list)->nAllocated <= 0) { \
		void *data; \
		int size_listGrow, alloc_listGrow; \
		size_listGrow = sizeof(*(list)->data) * (list)->size; \
		if (size_listGrow > (toSize)) \
			alloc_listGrow = size_listGrow; \
		else \
			alloc_listGrow = (toSize); \
		data = malloc(alloc_listGrow); \
		memcpy(data, (list)->data, size_listGrow); \
		(list)->data = data; \
		(list)->nAllocated = alloc_listGrow; \
	} else if ((list)->nAllocated < (toSize)) { \
		if ((toSize) - (list)->nAllocated < DEFAULT_INCREMENT) \
			(list)->nAllocated += DEFAULT_INCREMENT; \
		else \
			(list)->nAllocated = (toSize); \
		(CPP_ADJUST1(list)->data) = realloc((list)->data, (list)->nAllocated * sizeof(*(list)->data)); \
	} \
}

/*Append an element to the list, growing it if necessary*/
#define listAdd(list, item) { \
	listGrow((list), (list)->size + 1) \
	(list)->data[(list)->size++] = (item); \
}

/*Append source to target, growing it if necessary*/
#define listAppend(target, source) { \
	int t_listAppend; \
	if ((target)) \
		t_listAppend = (target)->size + (source)->size; \
	else \
		t_listAppend = (source)->size; \
	listGrow((target), t_listAppend) \
	while ((target)->size < t_listAppend) \
		(target)->data[(target)->size] = (source)->data[(target)->size++ - (t_listAppend - (source)->size)]; \
}

/*Copy source into target, growing if necessary*/
#define listCopy(target, source) { \
	listGrow((target), (source)->size); \
	(target)->size = (source)->size; \
	memcpy((target)->data, (source)->data, (source)->size * sizeof(*((source)->data))); \
}

/*Deallocate list-associated memory*/
#define listFree(list) { \
	if ((list)) { \
		if ((list)->nAllocated != 0) \
			free((list)->data); \
		free((list)); \
		list = NULL; \
	} \
}

/*Call function with a pointer to every element of the list*/
#define listMap(list, function) { \
	int i_tmp_listExec; \
	for (i_tmp_listExec = 0; i_tmp_listExec < (list)->size; ++i_tmp_listExec) \
		(function)((list)->data + i_tmp_listExec); \
}

/*In-place reverse a list*/
#define listReverse(list) { \
	char tmp_listReverse[sizeof(*(list)->data)]; \
	int i_listReverse; \
	for (i_listReverse = 0; i_listReverse < (list)->size/2; ++i_listReverse) { \
		memcpy(tmp_listReverse, (list)->data + i_listReverse, sizeof(*(list)->data)); \
		memcpy((list)->data + i_listReverse, (list)->data + (list)->size - i_listReverse - 1, sizeof(*(list)->data)); \
		memcpy((list)->data + (list)->size - i_listReverse - 1, tmp_listReverse, sizeof(*(list)->data)); \
	} \
}

#endif
