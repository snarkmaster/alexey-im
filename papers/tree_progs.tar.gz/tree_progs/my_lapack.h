#ifndef MY_LAPACK_H
#define MY_LAPACK_H

#ifdef USE_MKL
	#include "mkl.h"
#else
	#define DSYEVD dsyevd_
	extern void DSYEVD(char *JOBZ, char *UPLO, int *N, double *A, int *LDA, 
		double *W, double *WORK, int *LWORK, int *IWORK, int *LIWORK, int *INFO);
#endif

#endif
