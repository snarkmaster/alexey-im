#include <string.h>
#include <stdio.h>
#include "list.h"
#include "assert.h"

#define MAXN	32

typedef unsigned long long int Tree;
listDefine(Tree) TreeList;

#define min(a, b) (((a) < (b)) ? (a) : (b))

void search(TreeList trees, int *sizeindex, Tree t, int ceil_index, int n) 
{
	int i;
	if (n == 0)
		listAdd(trees, t << 1)
	else {
		int size = 1;
		int max = min(sizeindex[n], ceil_index);
		assert(max >= 0 && max <= trees->size);
		for (i = 0; i < max; ++i) {
			if (i == sizeindex[size])
				++size;
			search(trees, sizeindex, t << (2*size) | trees->data[i], i + 1, n - size);
		}
	}
}

int main(int argc, char **argv)
{
	TreeList trees;
	int sizeindex[MAXN + 1];
	int i, maxSize;

	if (argc < 2)
		return 1;
	else
		maxSize = atoi(argv[1]);

	listNewDefault(trees);
	sizeindex[0] = 0;
	#ifndef NDEBUG
		for (i = 1; i <= MAXN; ++i) /* We shouldn't touch these */
			sizeindex[i] = -10000000; 
	#endif
	
	for (i = 0; i < maxSize; ++i) {
		search(trees, sizeindex, 1, trees->size, i);
		sizeindex[i + 1] = trees->size;
		printf("%d size %d\n", sizeindex[i + 1] - sizeindex[i], i + 1);
	}
	
	printf("%d total\n", trees->size);

	maxSize = 1;	
	for (i = 0; i < trees->size; ++i) {
		int j;
		if (i == sizeindex[maxSize])
			++maxSize;
		for (j = maxSize*2 - 1; j >= 0; --j)
			if (((unsigned long)(trees->data[i] >> j)) % 2)
				putchar('(');
			else
				putchar(')');
		printf("\n");
	}
	
	return 0;
}

