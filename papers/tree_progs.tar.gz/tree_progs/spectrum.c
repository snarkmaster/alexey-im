#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "my_lapack.h"

typedef double real;

#define VALUES 15000
#define MAXN 1000
#define MAXW (2*MAXN+1)

int nval[] = {800, -1};
real lam[] = {0.2, 0.6, 0.8, 1.0, 1.3, 1.7, 2.1, 3.0, 4.5, 6.0, 8.0, 11.0, 15.0, -1};
/*
real lam[] = {0.1, 0.3, 0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 2.7, 3.5, 5.0, 7.0, 10, 12, 15,  -1};
*/

double ranf() 
{
	return ((real)random())/RAND_MAX; 
}

real gaussranf() 
{
	real x1, x2, w;
	do {
		x1 = 2.0 * ranf() - 1.0;
		x2 = 2.0 * ranf() - 1.0;
		w = x1 * x1 + x2 * x2;   
	} while ( w >= 1.0 );
	w = sqrt( (-2.0 * log( w ) ) / w );
	return x1 * w; /*we are wasting another gaussian rv, oh well*/
}

real triranf()
{
	return ranf() + ranf();
}

int main ()
{
	double lambda = 1.0;
	int i, j, k, l, m, n, lwork, one = 1, info;
	real mtrx[MAXN*MAXN];
	real e[MAXN], work[MAXW];
	real val, max;
	int iwork[1], trials;

	srandom(time(NULL));

	for (lambda = lam[m = 0]; lambda > 0; lambda=lam[++m]) {
		printf("--- doing lambda %f\n", lambda);
		for (n = nval[l = 0]; n > 0 && n <= MAXN; n = nval[++l]) {
			lwork = 2*n + 1;
			trials = VALUES/n;
			for (k = 0; k < trials; ++k) {
				for (i = 0; i < n; i++) {
					for (j = i; j < n; j++) {
						val = (real)random()/RAND_MAX;
						max = lambda/n;
						/* other things to try instead of 1.0: 
						 	gaussranf()
						 	ranf()
							triranf()
							((val < max/2.0) ? -1.0 : 1.0) for +/-1,
								which theoretically is equivalent to 1
						*/
						mtrx[i*n + j] = (val <= max) ? 1.0 : 0.0;
#ifdef D
						fprintf(stderr, "%f/%f ", val, max);
#endif
					}
#ifdef D
					fprintf(stderr, "\n");
#endif
				}
				
#ifdef D	
				if (MAXN <= 20) 
					for (i = 0; i < n; ++i) {
						fprintf(stderr, "[");
						for (j = 0; j < n; ++j) {
							fprintf(stderr, "%1.0f", mtrx[i*n + j]);
							if (j != n - 1)
								fprintf(stderr, ", ");
						}
						fprintf(stderr, "]; ");
					}
#endif 

				DSYEVD ("N","L", &n, (real*)mtrx, &n, e, work, &lwork, iwork, &one, &info);

				for (i = 0; i < n; i++) {
					printf("%f\n", e[i]);
				}
			}
		}
	}

	return 0;
}
